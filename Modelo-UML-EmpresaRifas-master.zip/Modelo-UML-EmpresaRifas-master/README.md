# Modelo-UML-EmpresaRifas
Diagrama UML para el proyecto de la Empresa de rifas, en formato de imagen y documento para Enterprise Architect
